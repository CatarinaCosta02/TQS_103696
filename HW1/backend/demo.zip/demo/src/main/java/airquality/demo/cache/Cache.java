package airquality.demo.cache;

import airquality.demo.models.City;

import java.util.HashMap;
import java.util.Map;

public class Cache {
    private Map<String, City> cache = new HashMap<String, City>();

}
