package airquality.demo.service;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AirQualityService {
    private static final String API_KEY = "a06833c3d40f4f8d93d4b2c47c39fa8f";
    private static final String API_URL = "http://api.weatherbit.io/v2.0/current/airquality?city=Raleigh";
    RestTemplate restTemplate = new RestTemplate();

    String url = API_URL + "&key=" + API_KEY;
    ResponseEntity<Object> response = restTemplate.getForEntity(url, Object.class);

}
