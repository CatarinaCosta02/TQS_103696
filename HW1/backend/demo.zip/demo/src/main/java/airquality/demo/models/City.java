package airquality.demo.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class City {
    @JsonProperty("city_name")
    private String cityName;
    @JsonProperty("lat")
    private double lat;
    @JsonProperty("lon")
    private double lon;
    @JsonProperty("data")
    private AirDataMetrics[] data;

    public City(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public City(String cityName) {
        this.cityName = cityName;
    }


}
